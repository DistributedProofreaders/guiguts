
# This is a .pm just to (try to) make some CPAN document converters
#  convert it happily as part of the dist's documentation tree.
package HTML::Element::traverse;
 # Time-stamp: "2002-11-22 23:53:39 MST"
use HTML::Element ();
$VERSION = $VERSION = $HTML::Element::VERSION;
1;

__END__

