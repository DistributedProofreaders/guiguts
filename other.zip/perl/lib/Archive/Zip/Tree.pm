# $Revision: 1.11 $
#

use Archive::Zip;

warn("Archive::Zip::Tree is deprecated; its methods have been moved into Archive::Zip.") if $^W;

1;
