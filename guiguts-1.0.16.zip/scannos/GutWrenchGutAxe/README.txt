# $Id: guiguts.pl 559 2011-08-30 02:53:44Z hmonroe $

This directory contains scanno files from the GutWrench suite in the original format (.txt) and in the GuiGuts format (.rc).