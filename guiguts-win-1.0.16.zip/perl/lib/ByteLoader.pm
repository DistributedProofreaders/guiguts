package ByteLoader;

use XSLoader ();

our $VERSION = '0.05';

XSLoader::load 'ByteLoader', $VERSION;

1;
__END__

