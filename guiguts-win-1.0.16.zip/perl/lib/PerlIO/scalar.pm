package PerlIO::scalar;
our $VERSION = '0.02';
use XSLoader ();
XSLoader::load 'PerlIO::scalar';
1;
__END__

