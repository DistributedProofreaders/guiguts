package PerlIO::via;
our $VERSION = '0.02';
use XSLoader ();
XSLoader::load 'PerlIO::via';
1;
__END__

