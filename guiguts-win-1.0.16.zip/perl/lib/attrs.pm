package attrs;
use XSLoader ();

$VERSION = "1.01";

XSLoader::load 'attrs', $VERSION;

1;
